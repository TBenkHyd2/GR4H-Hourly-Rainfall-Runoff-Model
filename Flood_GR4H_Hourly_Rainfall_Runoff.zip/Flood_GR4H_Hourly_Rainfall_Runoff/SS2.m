function SS2 = SS2(I,C);
% HYDROGRAMME Rapide
% Function calculates time delay for HU2 Aorccding GR4J FORTRAN(CEMAGREF-IRSTEA)
%Matlab code By T.Benkaci.

fI = I;
    if fI <= 0., 
        SS2=0.;
   elseif fI <= C,
                SS2=0.5*(fI/C)^(2.5);
       elseif fI < 2*C,
                SS2=1-0.5*(2-fI/C)^(2.5);
    elseif fI >= C,
            SS2=1.;

    end;


